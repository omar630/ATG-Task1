
<br><?php echo e(count($messages)); ?>

<?php if(count($messages)>0): ?>
	<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<ul class="list-group">
			<li class="list-group-item">
				Name:<?php echo e($message->name); ?></li>
				<li class="list-group-item">
				Name:<?php echo e($message->pincode); ?></li>
		</ul>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\task\resources\views/customers.blade.php ENDPATH**/ ?>