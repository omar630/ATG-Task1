	<div class="alert alert-success container">
		<strong>submitted succesfuly</strong>
	</div>
	<form method="get" action="/redirecttohome">
		<p>Click here to enter again</p>
		<input type="submit" name="submit">
	</form>
<?php /**PATH C:\xampp\htdocs\task\resources\views/success.blade.php ENDPATH**/ ?>