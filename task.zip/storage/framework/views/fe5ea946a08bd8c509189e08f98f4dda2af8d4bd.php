	<div class="alert alert-danger container">
		<strong>Data already Exists!.please Try again with different data</strong>
	</div>
<form action="/redirecttohome">
	<input type="submit" value="Try Again">
</form><?php /**PATH C:\xampp\htdocs\task\resources\views/error.blade.php ENDPATH**/ ?>