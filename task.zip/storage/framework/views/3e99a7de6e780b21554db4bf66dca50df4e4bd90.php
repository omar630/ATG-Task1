<?php if($message =='success'): ?>)
<div class="alert alert-success alert-block">
	<button type="button" class="close" data-dismiss="alert">×</button>	
        <strong>submitted</strong>
</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\task\resources\views/flashmessage.blade.php ENDPATH**/ ?>