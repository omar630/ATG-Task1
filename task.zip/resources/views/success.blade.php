<!-- if data is succesfully inserted in database this page is shown	-->
	<div class="alert alert-success container">
		<strong>submitted succesfuly</strong>
	</div>
	<form method="get" action="/redirecttohome">
		<p>Click here to enter again</p>
		<input type="submit" name="submit">
	</form>
