<!-- if data already exists in database this page is shown	-->
<div class="alert alert-danger container">
	<strong>Data already Exists!.please Try again with different data</strong>
</div>
<form action="/redirecttohome">
	<input type="submit" value="Try Again">
</form>